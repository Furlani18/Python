inteiros = [1, 2, 3, 4]
reais = [4, 5, 6]
strings = ["a", "b", "c"]
matriz = [inteiros, reais, strings]
inteiros = []
reais = []
strings = []
print(matriz)
print(len(matriz))
print(matriz[1])
print(len(matriz[1]))

nome = range(len(matriz))
print(nome)
for i in range(len(matriz)):
    for j in range(len(matriz[i])):
        print(matriz[i][j], end=" ")
    print()

M = []

for i in range(10):
    linha = []
    for j in range(12):
        linha.append(i + j)
    M.append(linha)
print(M)
for i in range(len(M)):
    for j in range(len(M[i])):
        print(M[i][j], end=" ")
    print()

     

